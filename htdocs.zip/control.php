<?php 
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "dbforjeff";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $ctrl = $_POST['arg_ctrl'];
    switch($ctrl) {
        case 'add_investor':
            $id = $_POST['arg_id'];
            $name = $_POST['arg_name'];
            $email = $_POST['arg_email'];
            $sql = "INSERT INTO investor_table (_InvestorId, _Name, _Email)
                    VALUES (" .$id. ", " .$name. ", " .$email. ")";
            if ($conn->query($sql) === TRUE) {
                echo "New record created successfully";
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
            break;
        case 'add_crypto':
            $id = $_POST['arg_id'];
            $name = $_POST['arg_name'];
            $value = $_POST['arg_value'];
            $sql = "INSERT INTO cryptocurrency_table (_CryptocurrencyId, _CryptoName, _CurrentValue)
                    VALUES (" .$id. ", " .$name. ", " .$value. ")";
            if ($conn->query($sql) === TRUE) {
                echo "New record created successfully";
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
            break;
        case 'buy_investment':
            $inv_id = $_POST['arg_id_inv'];
            $crypto_id = $_POST['arg_id_crypto'];
            $shares = $_POST['arg_shares'];
            $purchase = $_POST['arg_purchase'];
            $owned = $_POST['arg_owned'] ? 1 : 0;
            $sql = "INSERT INTO investment_table (_InvestorId, _CryptocurrencyId, _NumShares, _PurchasePrice, _StillOwned)
                    VALUES (" .$inv_id. ", " .$crypto_id. ", " .$shares. ", " .$purchase. ", " .$owned. ")";
            if ($conn->query($sql) === TRUE) {
                echo "New record created successfully";
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
            break;
        case 'sell_investment':
            $inv_id = $_POST['arg_id_inv'];
            $crypto_id = $_POST['arg_id_crypto'];
            $price = $_POST['arg_price'];
            $sql = "SELECT * FROM investment_table WHERE _InvestorId=" .$inv_id. " AND _CryptocurrencyId=" .$crypto_id;
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
            // output data of each row
                while($row = $result->fetch_assoc()) {
                    $profit = $price - $row['_PurchasePrice'];
                    $sql = "DELETE FROM investment_table WHERE _InvestorId=" .$inv_id. " AND _CryptocurrencyId=" .$crypto_id;
                    if ($conn->query($sql) === TRUE) {
                        echo $profit;
                    } else {
                        echo "Error deleting record: " . $conn->error;
                    }
                }
            } else {
                echo "0 results";
            }
            break;
        case 'view_investments':
            $sql = "SELECT investment_table._InvestorId, investment_table._CryptocurrencyId, investment_table._NumShares, investment_table._PurchasePrice, investment_table._StillOwned FROM investment_table INNER JOIN cryptocurrency_table ON investment_table._CryptocurrencyId=cryptocurrency_table._CryptocurrencyId ORDER BY cryptocurrency_table._CurrentValue DESC";
            $result = $conn->query($sql);

            $html = "";
            if ($result->num_rows > 0) {
            // output data of each row
                while($row = $result->fetch_assoc()) {
                    $html .= "<tr><td>" . $row['_InvestorId'] . "</td>";
                    $html .= "<td>" . $row['_CryptocurrencyId'] . "</td>";
                    $html .= "<td>" . $row['_NumShares'] . "</td>";
                    $html .= "<td>" . $row['_PurchasePrice'] . "</td>";
                    $html .= "<td>" . $row['_StillOwned'] . "</td></tr>";                }
                echo $html;
            } else {
                echo "0 results";
            }
            break;
        case 'view_investors':
            $sql = "SELECT * FROM investor_table ORDER BY _Name ASC";
            $result = $conn->query($sql);

            $html = "";
            if ($result->num_rows > 0) {
            // output data of each row
                while($row = $result->fetch_assoc()) {
                    $html .= "<tr><td>" . $row['_InvestorId'] . "</td>";
                    $html .= "<td>" . $row['_Name'] . "</td>";
                    $html .= "<td>" . $row['_Email'] . "</td></tr>";
                }
                echo $html;
            } else {
                echo "0 results";
            }
            break;
    }

    
    $conn->close();
?>