/*
 Navicat Premium Data Transfer

 Source Server         : localhost_3306
 Source Server Type    : MySQL
 Source Server Version : 100422
 Source Host           : localhost:3306
 Source Schema         : dbforjeff

 Target Server Type    : MySQL
 Target Server Version : 100422
 File Encoding         : 65001

 Date: 29/04/2022 20:28:21
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for cryptocurrency_table
-- ----------------------------
DROP TABLE IF EXISTS `cryptocurrency_table`;
CREATE TABLE `cryptocurrency_table`  (
  `_CryptocurrencyId` int(255) NOT NULL,
  `_CryptoName` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `_CurrentValue` double NOT NULL DEFAULT 0,
  PRIMARY KEY (`_CryptocurrencyId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of cryptocurrency_table
-- ----------------------------
INSERT INTO `cryptocurrency_table` VALUES (1, '1', 1);

-- ----------------------------
-- Table structure for investment_table
-- ----------------------------
DROP TABLE IF EXISTS `investment_table`;
CREATE TABLE `investment_table`  (
  `_InvestorId` int(255) NOT NULL,
  `_CryptocurrencyId` int(255) NOT NULL,
  `_NumShares` int(255) NOT NULL,
  `_PurchasePrice` double NOT NULL,
  `_StillOwned` int(1) NOT NULL,
  PRIMARY KEY (`_InvestorId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for investor_table
-- ----------------------------
DROP TABLE IF EXISTS `investor_table`;
CREATE TABLE `investor_table`  (
  `_InvestorId` int(255) NOT NULL,
  `_Name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `_Email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`_InvestorId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of investor_table
-- ----------------------------
INSERT INTO `investor_table` VALUES (1, '1', '1');

SET FOREIGN_KEY_CHECKS = 1;
