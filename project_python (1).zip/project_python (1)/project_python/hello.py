import sys


#get the parameter; args[1] is the first parameter

name = sys.argv[1];   

#echo the name to the web page

print("Hello " +  name + "<br> <br>");
